package com.sanselo.mod.network;

import com.sanselo.mod.SanseloMod;
import com.sanselo.mod.client.ClientData;
import com.sanselo.mod.client.ClientHooks;
import com.sanselo.mod.data.PlayerData;
import com.sanselo.mod.data.PlayerRole;
import com.sanselo.mod.story.StoryManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public class ModNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(SanseloMod.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, OpenScreenPacket.class, OpenScreenPacket::encode, OpenScreenPacket::decode, OpenScreenPacket::handle);
        CHANNEL.registerMessage(id++, SelectRolePacket.class, SelectRolePacket::encode, SelectRolePacket::decode, SelectRolePacket::handle);
        CHANNEL.registerMessage(id++, SyncPacket.class, SyncPacket::encode, SyncPacket::decode, SyncPacket::handle);
    }

    public static void sync(ServerPlayer sp) {
        PlayerData d = PlayerData.get(sp);
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new SyncPacket(d.role.ordinal(), d.composure, d.chapter));
    }

    public static void openRoleScreen(ServerPlayer sp) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new OpenScreenPacket());
    }

    // сервер -> клиент: открыть экран выбора роли
    public static class OpenScreenPacket {
        public static void encode(OpenScreenPacket m, FriendlyByteBuf b) {}
        public static OpenScreenPacket decode(FriendlyByteBuf b) { return new OpenScreenPacket(); }
        public static void handle(OpenScreenPacket m, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientHooks::openRoleScreen));
            ctx.get().setPacketHandled(true);
        }
    }

    // клиент -> сервер: выбранная роль
    public static class SelectRolePacket {
        private final int role;
        public SelectRolePacket(int role) { this.role = role; }
        public static void encode(SelectRolePacket m, FriendlyByteBuf b) { b.writeInt(m.role); }
        public static SelectRolePacket decode(FriendlyByteBuf b) { return new SelectRolePacket(b.readInt()); }
        public static void handle(SelectRolePacket m, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer sp = ctx.get().getSender();
                if (sp == null) return;
                PlayerRole[] roles = PlayerRole.values();
                if (m.role <= 0 || m.role >= roles.length) return;
                // роль выбирается один раз, смена: /role set
                if (PlayerData.get(sp).role == PlayerRole.NONE) {
                    StoryManager.startRole(sp, roles[m.role]);
                }
            });
            ctx.get().setPacketHandled(true);
        }
    }

    // сервер -> клиент: данные для HUD
    public static class SyncPacket {
        private final int role, composure, chapter;
        public SyncPacket(int role, int composure, int chapter) {
            this.role = role; this.composure = composure; this.chapter = chapter;
        }
        public static void encode(SyncPacket m, FriendlyByteBuf b) {
            b.writeInt(m.role); b.writeInt(m.composure); b.writeInt(m.chapter);
        }
        public static SyncPacket decode(FriendlyByteBuf b) {
            return new SyncPacket(b.readInt(), b.readInt(), b.readInt());
        }
        public static void handle(SyncPacket m, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                PlayerRole[] roles = PlayerRole.values();
                ClientData.role = roles[Math.max(0, Math.min(m.role, roles.length - 1))];
                ClientData.composure = m.composure;
                ClientData.chapter = m.chapter;
            });
            ctx.get().setPacketHandled(true);
        }
    }
}
