package com.sanselo.mod.client;

import com.sanselo.mod.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class RoleSelectScreen extends Screen {
    public RoleSelectScreen() {
        super(Component.literal("Выбор роли"));
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int cy = height / 2;
        addRenderableWidget(Button.builder(Component.literal("Санселло: Создатель-разрушитель"), b -> pick(1))
                .bounds(cx - 130, cy - 20, 260, 20).build());
        addRenderableWidget(Button.builder(Component.literal("jdh (Джон): гений-мироход"), b -> pick(2))
                .bounds(cx - 130, cy + 40, 260, 20).build());
    }

    private void pick(int role) {
        ModNetwork.CHANNEL.sendToServer(new ModNetwork.SelectRolePacket(role));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);
        long t = System.currentTimeMillis();
        for (int i = 0; i < 60; i++) {
            int x = (i * 131) % Math.max(1, width);
            int y = (int) ((i * 57 + t / (20 + i % 5 * 6)) % Math.max(1, height));
            int size = 1 + i % 3;
            int a = 60 + (int) (60 * Math.sin(t / 400.0 + i));
            g.fill(x, y, x + size, y + size, (a << 24) | (i % 2 == 0 ? 0x9AA8FF : 0xC8A0FF));
        }
        g.drawCenteredString(font, "Кем ты будешь?", width / 2, height / 2 - 60, 0xFFFFFF);
        g.drawCenteredString(font, "Магия осколков, самообладание, клоны", width / 2, height / 2 + 2, 0xAAAAAA);
        g.drawCenteredString(font, "Порталы, пустотная магия, сарказм", width / 2, height / 2 + 62, 0xAAAAAA);
        super.render(g, mouseX, mouseY, partial);
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean isPauseScreen() { return false; }
}
