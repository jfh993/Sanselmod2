package com.sanselo.mod.fx;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.phys.Vec3;

/** Серверные визуальные эффекты: заголовки, кольца, спирали, линии, безвредные молнии. */
public final class Fx {
    private Fx() {}

    /** Анимированный заголовок по центру экрана (появление, показ, затухание). */
    public static void title(ServerPlayer sp, String title, String subtitle) {
        sp.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 25));
        sp.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(subtitle).withStyle(ChatFormatting.GRAY)));
        sp.connection.send(new ClientboundSetTitleTextPacket(Component.literal(title).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)));
    }

    public static void ring(ServerLevel l, ParticleOptions p, double x, double y, double z, double r, int n) {
        for (int i = 0; i < n; i++) {
            double a = 2 * Math.PI * i / n;
            l.sendParticles(p, x + Math.cos(a) * r, y, z + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    public static void spiral(ServerLevel l, ParticleOptions p, double x, double y, double z, double r, double h, int n) {
        for (int i = 0; i < n; i++) {
            double f = (double) i / n;
            double a = f * Math.PI * 6;
            double rr = r * (1 - f * 0.5);
            l.sendParticles(p, x + Math.cos(a) * rr, y + f * h, z + Math.sin(a) * rr, 1, 0, 0, 0, 0);
        }
    }

    public static void line(ServerLevel l, ParticleOptions p, Vec3 a, Vec3 b, int steps) {
        for (int i = 0; i <= steps; i++) {
            Vec3 v = a.lerp(b, (double) i / steps);
            l.sendParticles(p, v.x, v.y, v.z, 1, 0, 0, 0, 0);
        }
    }

    /** Молния без урона и поджога, только вспышка и гром. */
    public static void lightning(ServerLevel l, double x, double y, double z) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(l);
        if (bolt != null) {
            bolt.moveTo(x, y, z);
            bolt.setVisualOnly(true);
            l.addFreshEntity(bolt);
        }
    }

    /** Вспышка вокруг игрока при смене главы или концовке. */
    public static void burst(ServerPlayer sp) {
        if (sp.level() instanceof ServerLevel l) {
            spiral(l, ParticleTypes.ENCHANT, sp.getX(), sp.getY(), sp.getZ(), 1.2, 2.5, 60);
            ring(l, ParticleTypes.END_ROD, sp.getX(), sp.getY() + 0.1, sp.getZ(), 1.5, 24);
        }
    }
}
