package com.sanselo.mod.registry;

import com.sanselo.mod.SanseloMod;
import com.sanselo.mod.item.AbilityItems;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SanseloMod.MODID);

    public static final RegistryObject<Item> SHARD = ITEMS.register("meteor_shard",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> MEMORY_PAGE = ITEMS.register("memory_page",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> ORE_ITEM = ITEMS.register("meteorite_ore",
            () -> new BlockItem(ModBlocks.METEORITE_ORE.get(), new Item.Properties()));

    public static final RegistryObject<Item> CLONE_DECOY = ITEMS.register("clone_decoy", AbilityItems.CloneDecoy::new);
    public static final RegistryObject<Item> SHARD_BLAST = ITEMS.register("shard_blast", AbilityItems.ShardBlast::new);
    public static final RegistryObject<Item> RIFT_STEP = ITEMS.register("rift_step", AbilityItems.RiftStep::new);
    public static final RegistryObject<Item> SHARD_SENSE = ITEMS.register("shard_sense", AbilityItems.ShardSense::new);
    public static final RegistryObject<Item> RIFT_PORTAL = ITEMS.register("rift_portal", AbilityItems.RiftPortal::new);
    public static final RegistryObject<Item> HEART = ITEMS.register("heart_of_rift", AbilityItems.HeartOfRift::new);
    public static final RegistryObject<Item> NAME_BOOK = ITEMS.register("name_book", AbilityItems.NameBook::new);
    public static final RegistryObject<Item> JOURNAL = ITEMS.register("story_journal", AbilityItems.Journal::new);
    public static final RegistryObject<Item> SHARD_SWORD = ITEMS.register("shard_sword", AbilityItems.ShardSword::new);
}
