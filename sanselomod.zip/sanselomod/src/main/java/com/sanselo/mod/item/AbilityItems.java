package com.sanselo.mod.item;

import com.sanselo.mod.data.PlayerData;
import com.sanselo.mod.data.PlayerRole;
import com.sanselo.mod.entity.BossEntity;
import com.sanselo.mod.entity.SilentCloneEntity;
import com.sanselo.mod.fx.Fx;
import com.sanselo.mod.registry.ModBlocks;
import com.sanselo.mod.registry.ModDimensions;
import com.sanselo.mod.registry.ModEntities;
import com.sanselo.mod.story.StoryManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class AbilityItems {

    /** Базовый предмет-способность: проверка роли и перезарядка. role == null: подходит любой роли. */
    public abstract static class RoleItem extends Item {
        private final PlayerRole role;
        private final int cooldown;

        protected RoleItem(PlayerRole role, int cooldown) {
            super(new Item.Properties().stacksTo(1).rarity(Rarity.RARE));
            this.role = role;
            this.cooldown = cooldown;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (level.isClientSide || !(player instanceof ServerPlayer sp)) return InteractionResultHolder.success(stack);
            PlayerData d = PlayerData.get(sp);
            if (d.role == PlayerRole.NONE || (role != null && d.role != role)) {
                sp.displayClientMessage(Component.literal("Эта сила тебе не принадлежит."), true);
                return InteractionResultHolder.fail(stack);
            }
            if (activate((ServerLevel) level, sp, d)) {
                sp.getCooldowns().addCooldown(this, cooldown);
            }
            return InteractionResultHolder.success(stack);
        }

        protected abstract boolean activate(ServerLevel level, ServerPlayer p, PlayerData d);
    }

    // ---------------- Санселло ----------------

    public static class CloneDecoy extends RoleItem {
        public CloneDecoy() { super(PlayerRole.SANSELLO, 300); }

        @Override
        protected boolean activate(ServerLevel level, ServerPlayer p, PlayerData d) {
            p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 100, 0));
            for (Mob m : level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(16), m -> m.getTarget() == p)) {
                m.setTarget(null);
            }
            level.sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 60, 0.5, 1, 0.5, 0.3);
            Fx.spiral(level, ParticleTypes.PORTAL, p.getX(), p.getY(), p.getZ(), 1.0, 2.2, 50);
            Fx.ring(level, ParticleTypes.SOUL_FIRE_FLAME, p.getX(), p.getY() + 0.1, p.getZ(), 1.6, 24);
            level.playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1f, 0.8f);
            p.displayClientMessage(Component.literal("Клон принял удар на себя."), true);
            return true;
        }
    }

    public static class ShardBlast extends RoleItem {
        public ShardBlast() { super(PlayerRole.SANSELLO, 100); }

        @Override
        protected boolean activate(ServerLevel level, ServerPlayer p, PlayerData d) {
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(6), e -> e != p)) {
                e.hurt(level.damageSources().playerAttack(p), 8f);
                Vec3 push = e.position().subtract(p.position()).normalize().scale(0.9);
                e.push(push.x, 0.4, push.z);
                e.hurtMarked = true;
            }
            level.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 120, 3, 1, 3, 0.2);
            level.playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_BREAK, SoundSource.PLAYERS, 2f, 0.5f);
            for (int r = 1; r <= 6; r++) {
                Fx.ring(level, ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 0.2 + r * 0.05, p.getZ(), r, 10 + r * 4);
            }
            Fx.ring(level, ParticleTypes.CRIT, p.getX(), p.getY() + 1, p.getZ(), 3, 30);
            d.changeComposure(p, -15);
            return true;
        }
    }

    // ---------------- jdh ----------------

    public static class RiftStep extends RoleItem {
        public RiftStep() { super(PlayerRole.JDH, 60); }

        @Override
        protected boolean activate(ServerLevel level, ServerPlayer p, PlayerData d) {
            Vec3 eye = p.getEyePosition();
            Vec3 look = p.getLookAngle();
            Vec3 end = eye.add(look.scale(10));
            BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            Vec3 target = hit.getType() == HitResult.Type.MISS ? end : hit.getLocation().subtract(look.scale(0.6));
            level.sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 40, 0.3, 0.8, 0.3, 0.2);
            Fx.line(level, ParticleTypes.END_ROD, p.position().add(0, 1, 0), target, 24);
            p.teleportTo(target.x, target.y - p.getEyeHeight(), target.z);
            p.fallDistance = 0;
            level.playSound(null, p.blockPosition(), SoundEvents.CHORUS_FRUIT_TELEPORT, SoundSource.PLAYERS, 1f, 1f);
            return true;
        }
    }

    public static class ShardSense extends RoleItem {
        public ShardSense() { super(PlayerRole.JDH, 200); }

        @Override
        protected boolean activate(ServerLevel level, ServerPlayer p, PlayerData d) {
            BlockPos c = p.blockPosition();
            int found = 0;
            for (BlockPos pos : BlockPos.betweenClosed(c.offset(-16, -16, -16), c.offset(16, 16, 16))) {
                if (level.getBlockState(pos).is(ModBlocks.METEORITE_ORE.get())) {
                    found++;
                    if (found <= 40) {
                        level.sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5, pos.getY() + 1.2, pos.getZ() + 0.5, 6, 0.2, 0.4, 0.2, 0.02);
                    }
                }
            }
            for (SilentCloneEntity cl : level.getEntitiesOfClass(SilentCloneEntity.class, p.getBoundingBox().inflate(24))) {
                cl.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0));
            }
            Fx.ring(level, ParticleTypes.END_ROD, p.getX(), p.getY() + 0.2, p.getZ(), 4, 20);
            Fx.ring(level, ParticleTypes.END_ROD, p.getX(), p.getY() + 0.2, p.getZ(), 8, 32);
            Fx.ring(level, ParticleTypes.END_ROD, p.getX(), p.getY() + 0.2, p.getZ(), 12, 44);
            p.displayClientMessage(Component.literal("Осколков поблизости: " + found), true);
            return true;
        }
    }

    // ---------------- общие ----------------

    /** Вход в Трещину и возврат. Доступен с главы 4. */
    public static class RiftPortal extends RoleItem {
        public RiftPortal() { super(null, 100); }

        @Override
        protected boolean activate(ServerLevel level, ServerPlayer p, PlayerData d) {
            if (d.chapter < 4) {
                p.displayClientMessage(Component.literal("Трещина ещё не открылась."), true);
                return false;
            }
            Fx.spiral(level, ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY(), p.getZ(), 1.2, 2.5, 60);
            MinecraftServer server = level.getServer();
            ServerLevel rift = server.getLevel(ModDimensions.RIFT);
            if (rift == null) {
                p.displayClientMessage(Component.literal("Измерение-Трещина не найдено (проверь данные мода)."), true);
                return false;
            }
            if (level.dimension() == ModDimensions.RIFT) {
                ServerLevel over = server.overworld();
                BlockPos spawn = p.getRespawnPosition();
                if (spawn == null || p.getRespawnDimension() != Level.OVERWORLD) {
                    spawn = over.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, over.getSharedSpawnPos());
                }
                p.teleportTo(over, spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5, p.getYRot(), p.getXRot());
            } else {
                p.teleportTo(rift, 0.5, 4, 0.5, p.getYRot(), p.getXRot());
                d.riftVisits++;
                Fx.spiral(rift, ParticleTypes.REVERSE_PORTAL, 0.5, 4, 0.5, 1.2, 2.5, 60);
                StoryManager.check(p);
            }
            return true;
        }
    }

    /** Вызывает финального противника в Трещине (глава 7). */
    public static class HeartOfRift extends RoleItem {
        public HeartOfRift() { super(null, 20); }

        @Override
        protected boolean activate(ServerLevel level, ServerPlayer p, PlayerData d) {
            if (level.dimension() != ModDimensions.RIFT) {
                p.displayClientMessage(Component.literal("Сердце оживает только в Трещине."), true);
                return false;
            }
            if (d.chapter != 7 && d.chapter != 13) {
                p.displayClientMessage(Component.literal("Время ещё не пришло."), true);
                return false;
            }
            if (!level.getEntitiesOfClass(BossEntity.class, p.getBoundingBox().inflate(100)).isEmpty()) {
                p.displayClientMessage(Component.literal("Он уже здесь."), true);
                return false;
            }
            BossEntity boss = ModEntities.BOSS.get().create(level);
            if (boss == null) return false;
            boss.moveTo(p.getX() + 6, p.getY(), p.getZ(), 90f, 0f);
            boss.setCustomName(Component.literal(d.chapter == 13 ? "Вея, отнимающая Искры"
                    : d.role == PlayerRole.SANSELLO ? "jdh, гений мультивселенной" : "Санселло, Осколочный"));
            boss.setPersistenceRequired();
            Fx.lightning(level, boss.getX(), boss.getY(), boss.getZ());
            Fx.ring(level, ParticleTypes.SOUL_FIRE_FLAME, boss.getX(), boss.getY() + 0.1, boss.getZ(), 2.5, 40);
            level.addFreshEntity(boss);
            level.playSound(null, p.blockPosition(), SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 1f, 0.7f);
            return true;
        }
    }

    /** Книга имён: ПКМ по Безмолвному клону пощадит его и назовёт по имени (глава 6+). */
    public static class NameBook extends Item {
        private static final String[] NAMES = {"лавочник Орин", "пекарь Мэй", "учительница Лиора", "кузнец Бран", "почтальон Ти",
                "садовница Эвелин", "рыбак Дамир", "повар Йонас", "сторож Эфраим", "танцовщица Силь", "лекарь Антос", "ткачиха Ронья"};

        public NameBook() { super(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)); }

        @Override
        public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
            if (player.level().isClientSide) return InteractionResult.SUCCESS;
            if (!(target instanceof SilentCloneEntity) || !(player instanceof ServerPlayer sp)) return InteractionResult.PASS;
            PlayerData d = PlayerData.get(sp);
            if (d.role == PlayerRole.NONE || d.chapter < 6) {
                sp.displayClientMessage(Component.literal("Книга пока молчит."), true);
                return InteractionResult.FAIL;
            }
            ServerLevel level = (ServerLevel) sp.level();
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, target.getX(), target.getY() + 1, target.getZ(), 25, 0.4, 0.8, 0.4, 0.05);
            level.playSound(null, target.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.5f, 1.2f);
            sp.sendSystemMessage(Component.literal("В книге есть его имя: " + NAMES[level.random.nextInt(NAMES.length)] + ". Клон кивает и растворяется.")
                    .withStyle(net.minecraft.ChatFormatting.AQUA, net.minecraft.ChatFormatting.ITALIC));
            Fx.spiral(level, ParticleTypes.ENCHANT, target.getX(), target.getY(), target.getZ(), 0.8, 2.0, 40);
            target.discard();
            d.spared++;
            d.cloneKills++;
            StoryManager.check(sp);
            return InteractionResult.SUCCESS;
        }
    }

    public static class Journal extends Item {
        public Journal() { super(new Item.Properties().stacksTo(1)); }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            if (!level.isClientSide && player instanceof ServerPlayer sp) StoryManager.showJournal(sp);
            return InteractionResultHolder.success(player.getItemInHand(hand));
        }
    }

    public static class ShardSword extends SwordItem {
        public ShardSword() { super(Tiers.DIAMOND, 4, -2.2f, new Item.Properties().rarity(Rarity.EPIC)); }

        @Override
        public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 0));
            if (target.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.REVERSE_PORTAL, target.getX(), target.getY() + 1, target.getZ(), 15, 0.3, 0.5, 0.3, 0.1);
            }
            return super.hurtEnemy(stack, target, attacker);
        }
    }
}
