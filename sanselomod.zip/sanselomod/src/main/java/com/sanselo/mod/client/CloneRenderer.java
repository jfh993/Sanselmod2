package com.sanselo.mod.client;

import com.sanselo.mod.entity.SilentCloneEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CloneRenderer extends HumanoidMobRenderer<SilentCloneEntity, HumanoidModel<SilentCloneEntity>> {
    // Замени на свою текстуру: assets/sanselomod/textures/entity/silent_clone.png
    private static final ResourceLocation TEX = new ResourceLocation("textures/entity/player/wide/steve.png");

    public CloneRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(SilentCloneEntity e) { return TEX; }
}
