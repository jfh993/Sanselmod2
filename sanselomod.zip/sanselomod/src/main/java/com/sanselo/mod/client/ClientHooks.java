package com.sanselo.mod.client;

import com.sanselo.mod.data.PlayerRole;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.ForgeGui;

public class ClientHooks {
    public static void openRoleScreen() {
        Minecraft.getInstance().setScreen(new RoleSelectScreen());
    }

    /** Шкала «Самообладание» для Санселло: плавное движение, пульсация и красная виньетка при низком значении. */
    public static void renderComposure(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        if (ClientData.role != PlayerRole.SANSELLO) return;
        int c = ClientData.composure;
        ClientData.shownComposure += (c - ClientData.shownComposure) * 0.12f;
        float shown = ClientData.shownComposure;
        float pulse = (float) (Math.sin(System.currentTimeMillis() / 220.0) * 0.5 + 0.5);

        if (c <= 30) {
            int a = (int) ((30 - c) / 30f * 40 + pulse * 25);
            int col = (a << 24) | 0x8B0000;
            int edge = Math.max(12, w / 10);
            g.fill(0, 0, w, edge, col);
            g.fill(0, h - edge, w, h, col);
            g.fill(0, edge, edge, h - edge, col);
            g.fill(w - edge, edge, w, h - edge, col);
        }

        int x = 10, y = 10, bw = 80;
        int shake = c <= 25 ? (int) (Math.sin(System.currentTimeMillis() / 40.0) * 1.5) : 0;
        g.fill(x - 1 + shake, y - 1, x + bw + 1 + shake, y + 9, 0xAA000000);
        int color = c > 50 ? 0xFF8A2BE2 : c > 25 ? 0xFFFF8C00 : (pulse > 0.5f ? 0xFFFF0000 : 0xFF990000);
        g.fill(x + shake, y, x + shake + (int) (bw * shown / 100f), y + 8, color);
        g.drawString(Minecraft.getInstance().font, "Самообладание: " + c, x + shake, y + 11, 0xFFFFFF);
    }
}
